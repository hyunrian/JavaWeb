package net.exam01;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class GuguServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		int num1 = Integer.valueOf(request.getParameter("num1"));
		int num2 = Integer.valueOf(request.getParameter("num2"));

		String html = "";
		
		if (!(1 <= num1 && num1 <= 9 && 1 <= num2 && num2 <= 9)) {
			html += "<script>"
					+ "alert('1부터 9 사이의 숫자로 입력하세요.');"
					+ " location.href = '/net_exam';"
					+ "</script>";
			out.print(html);
			return;
		}
		
		html += "<table border='1' style='text-align:center;'>";
		for (int i = 1; i <= 9; i++) {
			if (i == num2) {
				html += "<tr style='background-color:red; color:white;'>";
			} else {
				html += "<tr>";
			}
			
			html += "<td width='200px'>" + num1 + " * " + i + "</td>"
					+ "<td width='200px'>" + (num1*i) + "</td>"
					+ "</tr>";
		}
		html += "</table>";
		
		out.print(html);
		
	}

}
